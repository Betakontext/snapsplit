# profiles.py
"""
Copyright (C) 2026 Christoph Medicus
https://dev.betakontext.de
dev@betakontext.de

This file is part of SnapSplit

SnapSplit is free software; you can redistribute it and/or
modify it under the terms of the GNU General Public License
as published by the Free Software Foundation; either version 3
of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, see <https://www.gnu.org/licenses>.
"""

import math
import bpy
from bpy.props import (
    EnumProperty,
    FloatProperty,
    PointerProperty,
    IntProperty,
    BoolProperty,
)
from bpy.types import PropertyGroup

from .utils import current_language, is_lang_de

# ---------------------------
# Material profiles (tolerance per side, in mm)
# ---------------------------

# Konservative Standardwerte (FDM-orientiert)
MATERIAL_PROFILES = {
    "PLA": 0.25,
    "PETG": 0.30,
    "ABS": 0.25,
    "ASA": 0.25,
    "TPU": 0.35,
    "SLA": 0.10,
}

def _snapsplit_update_preview(self, context):
    """Property update callback to refresh or clear split preview planes."""
    try:
        from . import ops_split
        ops_split.update_split_preview_plane(context)
    except Exception:
        pass

def _is_de():
    """Return True if current UI language is German (best-effort)."""
    try:
        return current_language().lower().startswith("de")
    except Exception:
        return is_lang_de()

def _suggest_pin_segments_from_diameter(d_mm: float) -> int:
    """
    Heuristik für Segmente bei Zylinderpins nach Durchmesser (mm).
    Ziel: visuell rund ohne übertrieben dichte Meshes.
    """
    if d_mm <= 0:
        return 16
    base = int(round(math.pi * d_mm / 1.8))
    lo, hi = 12, 64
    if d_mm < 3.0:
        lo = 16
    return max(lo, min(hi, base))

def _mat_item_desc(key: str, val: float) -> str:
    # Kurz und einheitlich EN/DE
    return f"Recommended tolerance per side: {val:.2f} mm"

def _material_items():
    """Enum-Items für Materialprofile mit Tooltips."""
    return [(k, k, _mat_item_desc(k, v)) for k, v in MATERIAL_PROFILES.items()]

# ---------------------------
# Property group
# ---------------------------

class SnapSplitProps(PropertyGroup):
    """Scene-level settings for segmentation, preview, connectors, tolerances, and alignment."""
    _DE = _is_de()

    # Split / Preview
    split_offset_mm: FloatProperty(
        name="Split Offset (mm)" if not _DE else "Schnitt-Offset (mm)",
        description=("Offset of the cutting plane along the split axis (positive in axis direction)"
                     if not _DE else "Verschiebung der Schnittebene entlang der Achse (positiv in Achsrichtung)"),
        default=0.0,
        soft_min=-100000.0,
        soft_max=100000.0,
        update=_snapsplit_update_preview,
    )

    split_axis: EnumProperty(
        name="Split Axis" if not _DE else "Schnittachse",
        items=[
            ("X", "X", "Split along X" if not _DE else "Entlang X schneiden"),
            ("Y", "Y", "Split along Y" if not _DE else "Entlang Y schneiden"),
            ("Z", "Z", "Split along Z" if not _DE else "Entlang Z schneiden"),
        ],
        default="Z",
        update=_snapsplit_update_preview,
    )

    show_split_preview: BoolProperty(
        name="Show split preview" if not _DE else "Schnittvorschau anzeigen",
        description=("Show temporary orange planes at planned cut positions"
                     if not _DE else "Temporäre orange Ebenen als geplante Schnittpositionen anzeigen"),
        default=False,
        update=_snapsplit_update_preview,
    )

    parts_count: IntProperty(
        name="Number of Parts" if not _DE else "Anzahl Teile",
        default=2,
        min=2,
        max=64,
        description=("Number of desired segments (cut planes = parts - 1)"
                     if not _DE else "Anzahl gewünschter Segmente (Schnittebenen = Teile - 1)"),
        update=_snapsplit_update_preview,
    )

    # Performance/Workflow: Cap seams automatically during split
    cap_seams_during_split: BoolProperty(
        name="Cap seams during split" if not _DE else "Nähte beim Schnitt schließen",
        description=("Automatically close seams after splitting. With hollow/inner shell: precise outer/inner loop fill; without hollow: simple fill. May increase runtime."
                     if not _DE else "Wendet nach dem Schnitt automatisch den Randverschluss an. Mit Hollow/Innenhülle: präzise Außen/Innen-Loop-Füllung; ohne Hollow: einfache Füllung. Kann die Laufzeit erhöhen."),
        default=True,
    )

    # Connections
    connector_type: EnumProperty(
        name="Connector Type" if not _DE else "Verbinder-Typ",
        items=[
            ("CYL_PIN",
             "Cylinder Pin" if not _DE else "Zylinder-Pin",""),
            ("RECT_TENON",
             "Rectangular Tenon" if not _DE else "Rechteck-Zapfen",""),
            ("SNAP_PIN",
             "Snap Pin" if not _DE else "Snap-Pin",""),
            ("SNAP_TENON",
             "Snap Tenon" if not _DE else "Snap-Zapfen",""),
            ("PIN_HOLE",
             "Pin & Hole" if not _DE else "Pin & Bohrung",""),
            ("DOVETAIL_TAPER",
             "Dovetail (Tapered)" if not _DE else "Schwalbenschwanz (mit Schräge)",""),
            ("SNAP_CANTILEVER",
             "Snap-Fit (Cantilever)" if not _DE else "Schnapphaken (Kragarm)",""),
            ("BALL_SOCKET",
             "Ball & Socket" if not _DE else "Kugel & Schale",""),
            ("PIP_HINGE",
             "Print-in-Place Hinge" if not _DE else "Druckbares Scharnier (PiP)",""),
        ],
        default="CYL_PIN",
    )

    # Placement distribution
    connector_distribution: EnumProperty(
        name="Distribution" if not _DE else "Verteilung",
        description=("Distribute connectors along a line or a grid across the seam face"
                     if not _DE else "Verbinder entlang einer Linie oder als Raster über die Nahtfläche verteilen"),
        items=[
            ("LINE", "Line" if not _DE else "Linie",""),
            ("GRID", "Grid" if not _DE else "Raster",""),
        ],
        default="LINE",
    )

    connectors_per_seam: IntProperty(
        name="Connectors per Seam" if not _DE else "Verbinder pro Naht",
        default=3,
        min=1,
        max=128,
    )

    connectors_rows: IntProperty(
        name="Rows (GRID)" if not _DE else "Reihen (RASTER)",
        description=("Number of rows for grid distribution"
                     if not _DE else "Anzahl der Reihen bei Raster-Verteilung"),
        default=2,
        min=1,
        max=128,
    )

    # Globale Ränder (Default so, dass nichts überlappt, aber „nahezu voll“)
    connector_margin_pct: FloatProperty(
        name="Margin (%)" if not _DE else "Randabstand (%)",
        description=("Edge margin along the seam (and perpendicular in GRID) as percentage of part length (0–40% recommended)"
                     if not _DE else "Randabstand entlang der Naht (und senkrecht im Raster) als Prozent der Bauteillänge (0–40% empfohlen)"),
        default=3.0,
        min=0.0,
        soft_max=40.0,
        subtype='PERCENTAGE'
    )

    edge_margin_mm: FloatProperty(
        name="Edge margin (mm)" if not _DE else "Randabstand (mm)",
        description=("Minimum distance from seam edges (in mm) for connector placement"
                     if not _DE else "Mindestabstand zu Nahtkanten (in mm) für die Verbinderplatzierung"),
        default=4.0,
        min=0.0,
        soft_max=20.0,
    )

    # Snap options (active when connector_type == 'SNAP_PIN' or 'SNAP_TENON')
    snap_spheres_per_side: IntProperty(
        name="Spheres per side" if not _DE else "Sphären je Seite",
        description=("Number of snap spheres per side/around"
                     if not _DE else "Anzahl der Schnapp-Sphären je Seitenfläche/Umfang"),
        default=2,
        min=1,
        max=32,
    )

    snap_sphere_diameter_mm: FloatProperty(
        name="Sphere Ø (mm)" if not _DE else "Sphären-Ø (mm)",
        description=("Diameter of snap spheres"
                     if not _DE else "Durchmesser der Schnapp-Sphären"),
        default=2.0,
        min=0.5,
        soft_max=10.0,
    )

    snap_sphere_protrusion_mm: FloatProperty(
        name="Protrusion (mm)" if not _DE else "Überstand (mm)",
        description=("How far spheres protrude from side surface"
                     if not _DE else "Wie weit die Sphären aus der Seitenfläche herausstehen"),
        default=1.0,
        min=0.0,
        soft_max=5.0,
    )

    # Pin / Tenon dimensions (mm)
    pin_diameter_mm: FloatProperty(
        name="Pin Diameter (mm)" if not _DE else "Pin-Durchmesser (mm)",
        default=5.0,
        min=0.5,
        soft_max=50.0,
    )

    pin_length_mm: FloatProperty(
        name="Pin Length (mm)" if not _DE else "Pin-Länge (mm)",
        default=8.0,
        min=1.0,
        soft_max=200.0,
    )

    pin_segments: IntProperty(
        name="Segments" if not _DE else "Segmente",
        description=("Cylinder pin radial segments (visual smoothness)"
                     if not _DE else "Kreissegmente des Pins (nur Optik/Glätte)"),
        default=32,
        min=8,
        max=128,
    )

    tenon_width_mm: FloatProperty(
        name="Tenon Width (mm)" if not _DE else "Zapfen-Breite (mm)",
        default=6.0,
        min=1.0,
        soft_max=100.0,
    )

    tenon_depth_mm: FloatProperty(
        name="Tenon Depth (mm)" if not _DE else "Zapfen-Tiefe (mm)",
        default=8.0,
        min=1.0,
        soft_max=200.0,
    )

    add_chamfer_mm: FloatProperty(
        name="Chamfer (mm)" if not _DE else "Fase (mm)",
        default=0.3,
        min=0.0,
        soft_max=2.0,
    )

    # Insert depth
    pin_embed_pct: FloatProperty(
        name="Insert Depth (%)" if not _DE else "Einstecktiefe (%)",
        description=("Percentage of connector length recessed into part A"
                     if not _DE else "Prozentualer Anteil der Verbinderlänge, die in Teil A steckt"),
        default=50.0,
        min=0.0,
        max=100.0,
        subtype='PERCENTAGE'
    )

    # Tolerances / material profile
    material_profile: EnumProperty(
        name="Material Profiles" if not _DE else "Material-Profile",
        items=_material_items(),
        default="PETG",
        description=("Select a material profile to auto-fill tolerance per side"
                     if not _DE else "Materialprofil wählen, um die Toleranz pro Seite zu setzen"),
    )

    tol_override: FloatProperty(
        name="Tolerance per Face (mm)" if not _DE else "Toleranz pro Fläche (mm)",
        description=("Overrides material profile (0 = use profile value)"
                     if not _DE else "Überschreibt das Materialprofil (0 = Profilwert verwenden)"),
        default=0.0,
        min=0.0,
        soft_max=0.8,
    )

    def effective_tolerance(self) -> float:
        """Return the active tolerance per side, considering the override if set."""
        prof = MATERIAL_PROFILES.get(self.material_profile, 0.3)
        return prof if self.tol_override <= 0.0 else self.tol_override

    # ---------------------------
    # New per-type properties
    # ---------------------------

    # PIN_HOLE
    pin_fit_mode: EnumProperty(
        name="Fit mode" if not _DE else "Passung",
        items=[
            ("snug", "Snug" if not _DE else "Stramm", "~0.25 mm/side FDM, ~0.08 mm/side SLA"),
            ("sliding", "Sliding" if not _DE else "Leichtgängig", "~0.45 mm/side FDM, ~0.12 mm/side SLA"),
            ("glue_ready", "Glue-ready" if not _DE else "Klebe-Bereit", "~0.60 mm/side FDM, ~0.18 mm/side SLA"),
        ],
        default="snug",
        description=("Fit mode maps to per-side clearance (FDM vs SLA)"
                     if not _DE else "Passungsmodus bestimmt das Spiel je Seite (FDM vs SLA)"),
    )

    pin_hole_only: BoolProperty(
        name="Hole only (for metal pins)" if not _DE else "Nur Bohrung (für Metallstifte)",
        default=False,
    )

    # DOVETAIL_TAPER (Grundmaße) – Basiseinträge (werden durch Auto-Fit/Prozentmodus ggf. überschrieben)
    dovetail_length_mm: FloatProperty(
        name="Length (mm)" if not _DE else "Länge (mm)",
        default=20.0,
        min=1.0, soft_max=400.0,
    )
    dovetail_depth_mm: FloatProperty(
        name="Depth (mm)" if not _DE else "Tiefe (mm)",
        default=12.0,
        min=1.0, soft_max=200.0,
    )
    dovetail_width_mm: FloatProperty(
        name="Width (mm)" if not _DE else "Breite (mm)",
        default=16.0,
        min=1.0, soft_max=200.0,
    )
    dovetail_draft_deg: FloatProperty(
        name="Draft (°)" if not _DE else "Schräge (°)",
        default=1.5, min=0.0, soft_max=5.0,
        description=("Use 1–2° taper for progressive friction"
                     if not _DE else "1–2° Schräge für progressiven Sitz"),
    )
    dovetail_leadin_chamfer_mm: FloatProperty(
        name="Lead-in chamfer (mm)" if not _DE else "Einführfase (mm)",
        default=1.0,
        min=0.0, soft_max=3.0,
    )
    dovetail_clearance_scale: FloatProperty(
        name="Clearance scale" if not _DE else "Spiel-Skalierung",
        default=1.0, min=0.5, soft_max=2.0,
        description=("Multiplies material tolerance per side"
                     if not _DE else "Multipliziert Materialtoleranz je Seite"),
    )
    dovetail_slide_dir: EnumProperty(
        name="Slide direction" if not _DE else "Schieberichtung",
        items=[("+X","+X",""),("-X","-X",""),("+Y","+Y",""),("-Y","-Y","")],
        default="+X",
    )

    # DOVETAIL_TAPER (Auto-Preset / Proportional)
    dovetail_proportional_enabled: BoolProperty(
        name="Proportional scaling" if not _DE else "Proportionale Skalierung",
        default=True,
        description=("When enabled, dependent sizes keep their ratios when the master dimension changes."
                     if not _DE else "Wenn aktiviert, behalten abhängige Maße ihre Verhältnisse, wenn das Leitmaß geändert wird."),
    )
    dovetail_master_dim: EnumProperty(
        name="Master dimension" if not _DE else "Leitmaß",
        items=[("WIDTH","Width" if not _DE else "Breite",""),
               ("LENGTH","Length" if not _DE else "Länge",""),
               ("DEPTH","Depth" if not _DE else "Tiefe","")],
        default="WIDTH",
    )
    dovetail_auto_fit: EnumProperty(
        name="Auto-fit" if not _DE else "Auto-Anpassung",
        items=[("OFF","Off" if not _DE else "Aus",""),
               ("FIT_WIDTH","Fit width to seam" if not _DE else "Breite an Naht anpassen",""),
               ("FIT_LENGTH","Fit length to seam" if not _DE else "Länge an Naht anpassen","")],
        default="FIT_LENGTH",
    )
    dovetail_use_full_span: BoolProperty(
        name="Use full edge length" if not _DE else "Über gesamte Kantenlänge",
        default=True,
        description=("Use the entire seam span for dovetail length, honoring margins and inset."
                     if not _DE else "Gesamte Naht-Laufweite für die Länge nutzen (unter Berücksichtigung von Rändern und Randabzug)."),
    )
    dovetail_end_inset_mm: FloatProperty(
        name="End inset (mm)" if not _DE else "Randabzug (mm)",
        default=6.0,
        min=0.0, soft_max=10.0,
        description=("Additional inset at both ends when auto-fitting over the full span."
                     if not _DE else "Zusätzlicher Abzug an beiden Enden bei Auto-Fit über die volle Kantenlänge."),
    )
    dovetail_span_orientation: EnumProperty(
        name="Span orientation" if not _DE else "Spanausrichtung",
        items=[("AUTO","Auto (longer side)" if not _DE else "Auto (lange Seite)",""),
               ("SHORT","Short side" if not _DE else "Kurze Seite",""),
               ("LONG","Long side" if not _DE else "Lange Seite","")],
        default="AUTO",
    )

    # Width/Depth Fit-Modi: 20% der kurzen Seite (Default) oder manuell
    dovetail_fit_width_mode: EnumProperty(
        name="Width mode" if not _DE else "Breitenmodus",
        items=[("PERCENT_SHORT","% of short side" if not _DE else "% der kurzen Seite",""),
               ("MANUAL","Manual" if not _DE else "Manuell","")],
        default="PERCENT_SHORT",
    )
    dovetail_fit_width_pct: FloatProperty(
        name="Width %" if not _DE else "Breite %",
        description=("Width as percent of the short seam span (after margins)" if not _DE else "Breite als Prozent der kurzen Nahtspanne (nach Rändern)"),
        default=20.0, min=1.0, soft_max=100.0, subtype='PERCENTAGE',
    )
    dovetail_fit_depth_mode: EnumProperty(
        name="Depth mode" if not _DE else "Tiefenmodus",
        items=[("PERCENT_SHORT","% of short side" if not _DE else "% der kurzen Seite",""),
               ("MANUAL","Manual" if not _DE else "Manuell","")],
        default="PERCENT_SHORT",
    )
    dovetail_fit_depth_pct: FloatProperty(
        name="Depth %" if not _DE else "Tiefe %",
        description=("Depth as percent of the short seam span (after margins)" if not _DE else "Tiefe als Prozent der kurzen Nahtspanne (nach Rändern)"),
        default=20.0, min=1.0, soft_max=100.0, subtype='PERCENTAGE',
    )

    # Persistierte Verhältnisse (Proportional)
    dovetail_ratio_len: FloatProperty(
        name="k_len", default=2.5, min=0.01, soft_max=10.0,
        description="Internal: length/width ratio (kept when proportional scaling is enabled).",
        options={'HIDDEN'}
    )
    dovetail_ratio_depth: FloatProperty(
        name="k_depth", default=1.0, min=0.01, soft_max=5.0,
        description="Internal: depth/width ratio (kept when proportional scaling is enabled).",
        options={'HIDDEN'}
    )
    dovetail_ratio_chamfer: FloatProperty(
        name="k_chamfer", default=0.075, min=0.0, soft_max=0.5,
        description="Internal: chamfer/width ratio (kept when proportional scaling is enabled).",
        options={'HIDDEN'}
    )

    # BALL_SOCKET (Phase 3 implementation, properties defined now)
    ball_diameter_mm: FloatProperty(
        name="Ball Ø (mm)" if not _DE else "Kugel-Ø (mm)",
        default=12.0, min=4.0, soft_max=40.0,
    )
    ball_friction_target: EnumProperty(
        name="Friction" if not _DE else "Reibung",
        items=[
            ("tight", "Tight" if not _DE else "Fest", ""),
            ("medium", "Medium" if not _DE else "Mittel", ""),
            ("loose", "Loose" if not _DE else "Locker", ""),
        ],
        default="medium",
    )
    ball_socket_clearance_mm: FloatProperty(
        name="Socket clearance (mm)" if not _DE else "Buchsen-Spiel (mm)",
        default=0.0, min=0.0, soft_max=0.8,
        description=("0 uses friction + material profile" if not _DE else "0 nutzt Reibung + Materialprofil"),
    )
    ball_lip_thickness_mm: FloatProperty(
        name="Retention lip (mm)" if not _DE else "Halte-Lippe (mm)",
        default=1.2, min=0.0, soft_max=4.0,
    )
    ball_socket_open_angle_deg: FloatProperty(
        name="Open angle (°)" if not _DE else "Öffnungswinkel (°)",
        default=230.0, min=160.0, soft_max=300.0,
    )
    ball_leadin_fillet_mm: FloatProperty(
        name="Lead-in fillet (mm)" if not _DE else "Einführ-Radius (mm)",
        default=0.6, min=0.0, soft_max=2.0,
    )

    # SNAP_CANTILEVER (Phase 2 implementation, properties defined now)
    snap_cant_arm_len_mm: FloatProperty(
        name="Arm length (mm)" if not _DE else "Armlänge (mm)",
        default=18.0, min=4.0, soft_max=60.0,
    )
    snap_cant_arm_thk_mm: FloatProperty(
        name="Arm thickness (mm)" if not _DE else "Armdicke (mm)",
        default=2.2, min=0.8, soft_max=6.0,
    )
    snap_cant_arm_w_mm: FloatProperty(
        name="Arm width (mm)" if not _DE else "Armbreite (mm)",
        default=6.0, min=2.0, soft_max=40.0,
    )
    snap_cant_hook_undercut_mm: FloatProperty(
        name="Hook undercut (mm)" if not _DE else "Haken-Hinterschneidung (mm)",
        default=0.8, min=0.2, soft_max=2.0,
    )
    snap_cant_fillet_mm: FloatProperty(
        name="Base fillet (mm)" if not _DE else "Grundradius (mm)",
        default=1.2, min=0.4, soft_max=4.0,
        description=("≥ 0.5 × thickness recommended" if not _DE else "≥ 0,5 × Dicke empfohlen"),
    )
    snap_cant_leadin_chamfer_mm: FloatProperty(
        name="Lead-in chamfer (mm)" if not _DE else "Einführfase (mm)",
        default=0.6, min=0.0, soft_max=2.0,
    )
    snap_cant_stop_offset_mm: FloatProperty(
        name="Stop offset (mm)" if not _DE else "Anschlag-Versatz (mm)",
        default=0.2, min=0.0, soft_max=2.0,
    )
    snap_cant_clearance_scale: FloatProperty(
        name="Clearance scale" if not _DE else "Spiel-Skalierung",
        default=1.1, min=0.5, soft_max=2.0,
    )

    # PIP_HINGE (Phase 4 implementation, properties defined now)
    pip_hinge_type: EnumProperty(
        name="Hinge type" if not _DE else "Scharnier-Typ",
        items=[
            ("knuckle_pin", "Knuckle (pin)" if not _DE else "Laschen (Bolzen)", ""),
            ("living_web", "Living web" if not _DE else "Living Hinge", ""),
        ],
        default="knuckle_pin",
    )
    pip_gap_mm: FloatProperty(
        name="PIP gap (mm)" if not _DE else "PIP-Spalt (mm)",
        default=0.30, min=0.05, soft_max=1.0,
        description=("Typical: FDM 0.30 mm, SLA 0.10 mm" if not _DE else "Typisch: FDM 0,30 mm, SLA 0,10 mm"),
    )
    pip_hinge_width_mm: FloatProperty(
        name="Hinge width (mm)" if not _DE else "Scharnier-Breite (mm)",
        default=8.0, min=2.0, soft_max=60.0,
    )
    pip_hinge_thickness_mm: FloatProperty(
        name="Thickness (mm)" if not _DE else "Dicke (mm)",
        default=2.0, min=0.3, soft_max=6.0,
    )
    pip_segments_count: IntProperty(
        name="Segments" if not _DE else "Segmente",
        default=3, min=1, max=21,
    )
    pip_relief_fillet_mm: FloatProperty(
        name="Relief fillet (mm)" if not _DE else "Entlastungs-Radius (mm)",
        default=0.6, min=0.0, soft_max=2.0,
    )

    # UI foldouts
    ui_more_seg: BoolProperty(
        name="More segmentation settings",
        description="Show advanced segmentation options",
        default=False
    )
    ui_more_conn: BoolProperty(
        name="More connection settings",
        description="Show advanced connection/geometry options",
        default=False
    )
    ui_more_tol: BoolProperty(
        name="More tolerance settings",
        description="Show advanced tolerance options",
        default=False
    )
    ui_more_align: BoolProperty(
        name="More alignment settings",
        description="Show advanced alignment options",
        default=False
    )


# ---------------------------
# Registration
# ---------------------------

classes = (SnapSplitProps,)

def register():
    """Register property classes and attach to bpy.types.Scene."""
    for c in classes:
        bpy.utils.register_class(c)
    bpy.types.Scene.snapsplit = PointerProperty(type=SnapSplitProps)

def unregister():
    """Unregister property classes and detach from bpy.types.Scene."""
    if hasattr(bpy.types.Scene, "snapsplit"):
        del bpy.types.Scene.snapsplit
    for c in reversed(classes):
        bpy.utils.unregister_class(c)
